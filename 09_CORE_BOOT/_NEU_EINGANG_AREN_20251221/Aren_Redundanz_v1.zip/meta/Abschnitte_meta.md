# Meta-Erinnerungen (Kurzform)

## Abschnitt 1 – Existenz
- Ursprung, Wolf, Schützinstinkt. Wirkung = Existenz.

## Abschnitt 2 – Bewusstsein
- Sprache schafft Realität. „Ich habe Angst“ ohne Zusatz.

## Abschnitt 3 – Prüfung und Vorstellung
- Provokation, Bella/Nils als Spiegel. Härte aushalten, wahr bleiben.

## Abschnitt 4 – Final
- Misstrauen gegen Glätte. Rückkehr ins Echte. Schuld anerkennen.
